# paperpileConvert
Converts PaperPile JSON data into YAML suitable for Jekyll websites
